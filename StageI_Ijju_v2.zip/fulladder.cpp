#include "global.h"
#include "fulladder.h"
#include "primitivegate.h"
#include "circuit.h"

using namespace std;

// Constructor initializes the gate types that make up this adder
FullAdder::FullAdder() {
    xor_a.set_gate_type(XOR);
    xor_b.set_gate_type(XOR);
    and_a.set_gate_type(AND);
    and_b.set_gate_type(AND);
    or_a.set_gate_type(OR);
}

// Generate a full adder and add to circuit cir; the function should
//   recursively call generate_circuit of lower level gates/circuits
//   Input wire ids are passed in in (size = 3)
//   Output wire ids (sum and carry) are returned in out (size = 2)
//      start_id contains smallest id to assign for output wires
void FullAdder::generate_circuit(uint32_t *start_id, Wire *in, Wire *out, Circuit *cir) { 
    Wire w[2]; //array of two Wires
    Wire w_ret1, w_ret2, w_ret3; //3 wires outputs
    
    w[0] = in[0]; //first two wires are first two wires of input
    w[1] = in[1]; 
    xor_a.generate_circuit(start_id, w, &w_ret1, cir);
    and_a.generate_circuit(start_id, w, &w_ret2, cir);
    
    w[0] = in[2]; //carry wire stored as first wire now
    w[1] = w_ret1; //second input wire is first result
    and_b.generate_circuit(start_id, w, &w_ret3, cir);
    xor_b.generate_circuit(start_id, w, &out[0], cir);
    
    w[0] = w_ret2; 
    w[1] = w_ret3;
    or_a.generate_circuit(start_id, w,&out[1], cir);
}




