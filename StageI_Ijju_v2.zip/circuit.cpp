#include <iostream>
#include <cassert>
#include <iomanip>

#include "global.h"
#include "circuit.h"


Circuit::Circuit() {
}

// Add a primitive Gate to the circuit
void Circuit::add_gate(Gate g) {
    gates.push_back(g);
}

// Add an input wire to the circuit
void Circuit::add_input(IO m) {
    input_map.push_back(m);
}

// Add an output wire to the circuit
void Circuit::add_output(IO m) {
    output_map.push_back(m);
}

// Assign bit values to the input wires
void Circuit::set_boolean_inputs(bool *vals) {
    for (int i=0; i<input_map.size(); i++) {
        input_map.at(i).value = vals[i];
    }
}

// Obtain output wire values in boolean array vals
void Circuit::get_boolean_outputs(bool *vals) {
    for (int i=0; i<output_map.size(); i++) {
        vals[i] = output_map.at(i).value;
    }
}

// Obtain the output of the circuit as decimal number
uint64_t Circuit::get_numeric_output() {
    uint64_t res = 0;
    bool val;
    
    for (int i=0; i<output_map.size(); i++) {
        val = output_map.at(i).value;
        res = ((uint64_t)val << i) | res;
    }
    
    return res;
}

// Print the circuit (input wire ids, gates with input/output wire ids, and output
//  wire ids)
void Circuit::print() {
    
    std::cout << "\nInputs\n";
    std::cout << "-----------------------------------\n";
    for (int i=0; i<input_map.size(); i++) {
        std::cout << input_map.at(i).id << "\n";
    }
    
    std::cout << "\nCircuit\n";
    std::cout << "-----------------------------------\n";
    Gate g;
    for (int i=0; i<gates.size(); i++) {
        g = gates.at(i);
        switch (g.type) {
            case AND: std::cout << "AND."; break;
            case OR: std::cout << " OR."; break;
            case XOR: std::cout << "XOR."; break;
            default: std::cout << "UKN."; break;
        }
        
        std::cout << g.id << "\t" << g.in1 << "\t" << g.in2 << "\n";
    }
    
    std::cout << "\nOutputs\n";
    std::cout << "-----------------------------------\n";
    for (int i=0; i<output_map.size(); i++) {
        std::cout << output_map.at(i).id << "\n";
    }
}

Gate& Circuit::gate_with_id(uint64_t *id){
    for(int i = 0; i < gates.size(); i ++){
        if (*&gates.at(i).id == *id){
            //std::cout<<"        GATE: "<<*id<<" VALUE: "<< gates.at(i).value<<"\n";
            return gates.at(i);
        }
    }
    return gates.at(-1);
}


bool Circuit::recurse(uint64_t *id, std::vector<IO> *map){
    //IO input, already have value
    if(*id < input_map.size()){
        //std::cout << "      GATE ID: " << *id << ", VALUE: " << input_map[*id].value << "\n";
        return input_map[*id].value;
    }
    //couldn't figure out how to do without a search
    Gate g = gate_with_id(id);
    if(gate_with_id(id).evaluated == true) return gate_with_id(id).value;
    else {
        gate_with_id(id).evaluated = true;
        //get values for two wires
        recurse(&gate_with_id(id).in1, &input_map);
        recurse(&gate_with_id(id).in2, &input_map);
        //compute output depending on gate type
        uint64_t g1val;
        uint64_t g2val;
        switch(g.type){
            case AND:
                if(g.in1 < input_map.size()){
                    g1val = input_map[g.in1].value;
                }else{
                    g1val = gate_with_id(&g.in1).value;
                }
                if(g.in2 < input_map.size()){
                    g2val = input_map[g.in2].value;
                }else{
                    g2val = gate_with_id(&g.in2).value;
                }
                g.value = g1val & g2val;
                //std::cout << "  GATE ID: " << g.id << ", VALUE: " << g.value << ", TYPE: AND, INPUT IDS: "
                //<< g.in1 << ", " << g.in2 << "\n";
                return g.value;
            case OR:
                if(g.in1 < input_map.size()){
                    g1val = input_map[g.in1].value;
                }else{
                    g1val = gate_with_id(&g.in1).value;
                }
                if(g.in2 < input_map.size()){
                    g2val = input_map[g.in2].value;
                }else{
                    g2val = gate_with_id(&g.in2).value;
                }
                g.value = g1val | g2val;
                //std::cout << "  GATE ID: " << g.id << ", VALUE: " << g.value << ", TYPE: OR, INPUT IDS: "
                //<< g.in1 << ", " << g.in2 << "\n";
                return g.value;
            case XOR:
                if(g.in1 < input_map.size()){
                    g1val = input_map[g.in1].value;
                }else{
                    g1val = gate_with_id(&g.in1).value;
                }
                if(g.in2 < input_map.size()){
                    g2val = input_map[g.in2].value;
                }else{
                    g2val = gate_with_id(&g.in2).value;
                }
                g.value = g1val ^ g2val;
                //std::cout << "  GATE ID: " << g.id << ", VALUE: " << g.value << ", TYPE: XOR, INPUT IDS: "
                //<< g.in1 << ", " << g.in2 << ", INPUT VALS: " << g1val << ", " << g2val << "\n";
                return g.value;
        }
    }
}

// Evaluate the circuit after input wires have been assigned values
//  values for each output wire needs to be computed
void Circuit::evaluate_boolean_circuit() {
    for(int i = 0; i < output_map.size(); i ++){
        output_map.at(i).value = recurse(&output_map.at(i).id, &output_map);
        //std::cout << "OUTPUT MAP VALUE at " << i << ": " <<output_map.at(i).value << "\n";
    }
}

