#include "global.h"
#include "binaryadder.h"
#include "fulladder.h"
#include "circuit.h"

// Constructor initializes the full adder array that make this b-bit adder
BinaryAdder::BinaryAdder(uint32_t b) {
    fa = new FullAdder[b];
    bitlen = b;
}

// Generate a binary adder and add to circuit cir; the function should
//   recursively call generate_circuit of lower level gates/circuits
//   Input wire ids are passed in in (size = 2*bitlen+1)
//   Output wire ids (sum and carry) are returned in out (size = bitlen+1)
//      start_id contains smallest id to assign for output wires
void BinaryAdder::generate_circuit(uint32_t *start_id, Wire *in, Wire *out, Circuit *cir) {
    Wire win[3]; //input wires
    win[2] = in[2*bitlen]; //carry bit
    Wire wout[2]; //output wires
    
    //for every adder
    for(int i = 0; i < bitlen; i ++){
        win[0] = in[2*i];
        win[1] = in[2*i + 1];
        fa[i].generate_circuit(start_id, win, wout, cir);
        out[i] = wout[0]; //set out sum bit
        win[2] = wout[1]; //new carry bit
    }
    
    //set final out carry bit
    out[bitlen] = wout[1];
}
